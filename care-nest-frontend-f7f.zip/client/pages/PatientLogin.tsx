import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Heart } from "lucide-react";

export default function PatientLogin() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    patientId: "",
    doctorId: "",
    password: "",
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Store in localStorage for demo purposes
    localStorage.setItem("patient", JSON.stringify(formData));
    navigate("/patient/dashboard");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-secondary-50 to-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <Link to="/login" className="inline-flex items-center gap-2 mb-4 hover:opacity-80">
            <Heart className="w-6 h-6 text-primary fill-primary" />
            <h1 className="text-2xl font-bold text-foreground">CareNest</h1>
          </Link>
          <h2 className="text-2xl font-bold text-foreground">Patient Login</h2>
          <p className="text-muted-foreground text-sm mt-2">
            Access your health records
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="bg-white rounded-xl p-6 border border-border space-y-4">
            {/* Name */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Full Name
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                placeholder="John Doe"
                className="w-full px-4 py-2.5 rounded-lg border border-input bg-white text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition"
                required
              />
            </div>

            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Email Address
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                placeholder="john@email.com"
                className="w-full px-4 py-2.5 rounded-lg border border-input bg-white text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition"
                required
              />
            </div>

            {/* Patient ID */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Patient ID
              </label>
              <input
                type="text"
                name="patientId"
                value={formData.patientId}
                onChange={handleInputChange}
                placeholder="PID-001"
                className="w-full px-4 py-2.5 rounded-lg border border-input bg-white text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition font-mono text-sm"
                required
              />
            </div>

            {/* Doctor ID */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Doctor ID <span className="text-accent">*</span>
              </label>
              <input
                type="text"
                name="doctorId"
                value={formData.doctorId}
                onChange={handleInputChange}
                placeholder="DOC-XXXXXXXXX"
                className="w-full px-4 py-2.5 rounded-lg border border-input bg-white text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition font-mono text-sm"
                required
              />
              <p className="text-xs text-muted-foreground mt-1">
                Required to link with your doctor
              </p>
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Password
              </label>
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleInputChange}
                placeholder="••••••••"
                className="w-full px-4 py-2.5 rounded-lg border border-input bg-white text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition"
                required
              />
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full bg-primary hover:bg-primary-300 text-primary-foreground font-semibold py-3 rounded-lg transition-colors duration-200 shadow-sm hover:shadow-md"
          >
            Login / Register under Doctor
          </button>

          {/* Back Link */}
          <p className="text-center text-sm text-muted-foreground">
            <Link to="/login" className="text-primary font-medium hover:text-primary-300">
              Back to Role Selection
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
}
