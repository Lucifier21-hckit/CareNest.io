import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Heart } from "lucide-react";

export default function DoctorSignup() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    clinic: "",
    doctorId: "",
    password: "",
  });

  const handleGenerateDoctorId = () => {
    const newId = `DOC-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
    setFormData((prev) => ({ ...prev, doctorId: newId }));
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Store in localStorage for demo purposes
    localStorage.setItem("doctor", JSON.stringify(formData));
    navigate("/doctor/dashboard");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary-50 to-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <Link to="/login" className="inline-flex items-center gap-2 mb-4 hover:opacity-80">
            <Heart className="w-6 h-6 text-primary fill-primary" />
            <h1 className="text-2xl font-bold text-foreground">CareNest</h1>
          </Link>
          <h2 className="text-2xl font-bold text-foreground">Doctor Registration</h2>
          <p className="text-muted-foreground text-sm mt-2">
            Create your professional account
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="bg-white rounded-xl p-6 border border-border space-y-4">
            {/* Full Name */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Full Name
              </label>
              <input
                type="text"
                name="fullName"
                value={formData.fullName}
                onChange={handleInputChange}
                placeholder="Dr. Jane Smith"
                className="w-full px-4 py-2.5 rounded-lg border border-input bg-white text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition"
                required
              />
            </div>

            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Email Address
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                placeholder="jane@clinic.com"
                className="w-full px-4 py-2.5 rounded-lg border border-input bg-white text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition"
                required
              />
            </div>

            {/* Clinic / Address */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Clinic / Address
              </label>
              <input
                type="text"
                name="clinic"
                value={formData.clinic}
                onChange={handleInputChange}
                placeholder="City Medical Center, 123 Health St"
                className="w-full px-4 py-2.5 rounded-lg border border-input bg-white text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition"
                required
              />
            </div>

            {/* Doctor ID */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="block text-sm font-medium text-foreground">
                  Doctor ID
                </label>
                <button
                  type="button"
                  onClick={handleGenerateDoctorId}
                  className="text-xs text-primary hover:text-primary-200 font-medium transition"
                >
                  Generate
                </button>
              </div>
              <input
                type="text"
                name="doctorId"
                value={formData.doctorId}
                onChange={handleInputChange}
                placeholder="DOC-XXXXXXXXX"
                className="w-full px-4 py-2.5 rounded-lg border border-input bg-white text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition font-mono text-sm"
                required
              />
              <p className="text-xs text-muted-foreground mt-1">
                Unique identifier shared with patients
              </p>
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Password
              </label>
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleInputChange}
                placeholder="••••••••"
                className="w-full px-4 py-2.5 rounded-lg border border-input bg-white text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition"
                required
              />
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full bg-primary hover:bg-primary-300 text-primary-foreground font-semibold py-3 rounded-lg transition-colors duration-200 shadow-sm hover:shadow-md"
          >
            Create Doctor Account
          </button>

          {/* Sign In Link */}
          <p className="text-center text-sm text-muted-foreground">
            Already have an account?{" "}
            <Link to="/login" className="text-primary font-medium hover:text-primary-300">
              Sign In
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
}
