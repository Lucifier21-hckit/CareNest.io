import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { LogOut, Plus, Upload, AlertCircle } from "lucide-react";

interface Medicine {
  id: string;
  name: string;
  serialNo: string;
  expiryDate: string;
  quantity: number;
}

interface Prescription {
  id: string;
  date: string;
  details: string;
}

interface Vital {
  id: string;
  type: string;
  value: string;
  unit: string;
  date: string;
}

const MOCK_MEDICINES: Medicine[] = [
  {
    id: "1",
    name: "Metformin 500mg",
    serialNo: "MET-2024-001",
    expiryDate: "2025-06-30",
    quantity: 45,
  },
  {
    id: "2",
    name: "Lisinopril 10mg",
    serialNo: "LIS-2024-002",
    expiryDate: "2025-08-15",
    quantity: 8,
  },
  {
    id: "3",
    name: "Atorvastatin 20mg",
    serialNo: "ATO-2024-003",
    expiryDate: "2025-12-31",
    quantity: 25,
  },
  {
    id: "4",
    name: "Aspirin 81mg",
    serialNo: "ASP-2024-004",
    expiryDate: "2024-11-30",
    quantity: 60,
  },
];

const MOCK_PRESCRIPTIONS: Prescription[] = [
  {
    id: "1",
    date: "2024-01-15",
    details: "Type 2 Diabetes Management - Continue current medications",
  },
  {
    id: "2",
    date: "2024-01-01",
    details: "Hypertension Control - Maintain dosage",
  },
];

const MOCK_VITALS: Vital[] = [
  { id: "1", type: "BP", value: "130/85", unit: "mmHg", date: "2024-01-15" },
  { id: "2", type: "Sugar", value: "145", unit: "mg/dL", date: "2024-01-15" },
  {
    id: "3",
    type: "Weight",
    value: "180",
    unit: "lbs",
    date: "2024-01-14",
  },
];

export default function PatientDashboard() {
  const navigate = useNavigate();
  const [patient, setPatient] = useState<any>(null);
  const [medicines, setMedicines] = useState<Medicine[]>(MOCK_MEDICINES);
  const [prescriptions] = useState<Prescription[]>(MOCK_PRESCRIPTIONS);
  const [vitals, setVitals] = useState<Vital[]>(MOCK_VITALS);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [uploadType, setUploadType] = useState<string>("");
  const [newVitalValue, setNewVitalValue] = useState("");
  const [newVitalUnit, setNewVitalUnit] = useState("");

  useEffect(() => {
    // Load patient from localStorage
    const patientData = localStorage.getItem("patient");
    if (patientData) {
      setPatient(JSON.parse(patientData));
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("patient");
    window.location.href = "/login";
  };

  const handleUploadVital = () => {
    if (newVitalValue.trim() && uploadType) {
      const newVital: Vital = {
        id: String(vitals.length + 1),
        type: uploadType,
        value: newVitalValue,
        unit: newVitalUnit || "unit",
        date: new Date().toISOString().split("T")[0],
      };
      setVitals([newVital, ...vitals]);
      setNewVitalValue("");
      setNewVitalUnit("");
      setUploadType("");
      setShowUploadModal(false);
    }
  };

  if (!patient) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-foreground mb-4">Loading...</p>
          <Link
            to="/login"
            className="text-primary hover:text-primary-300 font-medium"
          >
            Back to Login
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-white border-b border-border sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 md:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-secondary-50 flex items-center justify-center">
                <span className="text-lg font-bold text-secondary-700">
                  {patient.name
                    .split(" ")
                    .map((n: string) => n[0])
                    .join("")}
                </span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">
                  {patient.name}
                </h1>
                <p className="text-sm text-muted-foreground font-mono">
                  {patient.patientId}
                </p>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-4 py-2 text-foreground hover:bg-secondary-50 rounded-lg transition"
            >
              <LogOut className="w-4 h-4" />
              <span className="text-sm font-medium">Logout</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 md:px-8 py-12">
        {/* Profile Section */}
        <div className="bg-white rounded-2xl p-8 mb-8 border border-border shadow-sm">
          <h2 className="text-2xl font-bold text-foreground mb-6">
            Your Profile
          </h2>

          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <div className="w-32 h-32 rounded-full bg-gradient-to-br from-secondary-50 to-secondary-100 flex items-center justify-center mb-6">
                <span className="text-4xl font-bold text-secondary-700">
                  {patient.name
                    .split(" ")
                    .map((n: string) => n[0])
                    .join("")}
                </span>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <p className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
                  Name
                </p>
                <p className="text-lg font-semibold text-foreground mt-1">
                  {patient.name}
                </p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
                  Patient ID
                </p>
                <p className="text-lg font-mono font-semibold text-foreground mt-1">
                  {patient.patientId}
                </p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
                  Doctor ID (Assigned)
                </p>
                <p className="text-lg font-mono font-semibold text-primary mt-1">
                  {patient.doctorId}
                </p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
                  Email
                </p>
                <p className="text-lg font-semibold text-foreground mt-1">
                  {patient.email}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Medicine Management Section */}
        <div className="bg-white rounded-2xl p-8 mb-8 border border-border shadow-sm">
          <h2 className="text-2xl font-bold text-foreground mb-6">
            My Medicines
          </h2>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left px-4 py-3 font-semibold text-foreground">
                    Medicine Name
                  </th>
                  <th className="text-left px-4 py-3 font-semibold text-foreground">
                    Serial No
                  </th>
                  <th className="text-left px-4 py-3 font-semibold text-foreground">
                    Expiry Date
                  </th>
                  <th className="text-left px-4 py-3 font-semibold text-foreground">
                    Quantity
                  </th>
                  <th className="text-left px-4 py-3 font-semibold text-foreground">
                    Action
                  </th>
                </tr>
              </thead>
              <tbody>
                {medicines.map((medicine) => (
                  <tr key={medicine.id} className="border-b border-border hover:bg-secondary-50 transition">
                    <td className="px-4 py-3 font-medium text-foreground">
                      {medicine.name}
                    </td>
                    <td className="px-4 py-3 text-muted-foreground font-mono text-xs">
                      {medicine.serialNo}
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">
                      {medicine.expiryDate}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-foreground">
                          {medicine.quantity}
                        </span>
                        {medicine.quantity < 10 && (
                          <span className="flex items-center gap-1 px-2 py-1 rounded-lg bg-accent-50 text-accent-600 text-xs font-medium">
                            <AlertCircle className="w-3 h-3" />
                            Low
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      {medicine.quantity < 10 && (
                        <button className="px-3 py-1.5 rounded-lg bg-accent hover:bg-accent-100 text-accent-600 font-medium text-xs transition-colors cursor-not-allowed opacity-50">
                          Order Now
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Prescription History */}
        <div className="bg-white rounded-2xl p-8 mb-8 border border-border shadow-sm">
          <h2 className="text-2xl font-bold text-foreground mb-6">
            Prescription History
          </h2>

          <div className="space-y-4">
            {prescriptions.map((prescription) => (
              <div
                key={prescription.id}
                className="border border-border rounded-xl p-6 hover:border-primary-300 transition"
              >
                <p className="text-sm text-muted-foreground mb-2">
                  {prescription.date}
                </p>
                <p className="text-lg font-semibold text-foreground">
                  {prescription.details}
                </p>
              </div>
            ))}
          </div>

          <button className="mt-6 flex items-center gap-2 px-4 py-2.5 bg-secondary-50 hover:bg-secondary-100 text-secondary-700 font-medium rounded-lg transition-colors text-sm">
            <Upload className="w-4 h-4" />
            Upload New Prescription
          </button>
        </div>

        {/* Vitals & Scans Upload */}
        <div className="bg-white rounded-2xl p-8 border border-border shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-foreground">
              Vitals & Medical Records
            </h2>
            <button
              onClick={() => setShowUploadModal(true)}
              className="flex items-center gap-2 px-4 py-2.5 bg-primary hover:bg-primary-300 text-primary-foreground font-medium rounded-lg transition-colors text-sm"
            >
              <Upload className="w-4 h-4" />
              Upload Vital
            </button>
          </div>

          {/* Recent Vitals */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-foreground mb-4">
              Recent Vitals
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {vitals.map((vital) => (
                <div
                  key={vital.id}
                  className="border border-border rounded-xl p-4 hover:border-primary-300 transition"
                >
                  <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    {vital.type}
                  </p>
                  <p className="text-2xl font-bold text-primary mt-2">
                    {vital.value} <span className="text-sm text-muted-foreground">{vital.unit}</span>
                  </p>
                  <p className="text-xs text-muted-foreground mt-2">
                    {vital.date}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Upload Types */}
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-4">
              Available Upload Types
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {["CT Scan", "X-Ray", "Blood Report", "ECG"].map((type) => (
                <div
                  key={type}
                  className="border border-border rounded-xl p-4 text-center hover:border-primary-300 transition cursor-pointer hover:bg-primary-50"
                >
                  <Upload className="w-6 h-6 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm font-medium text-foreground">{type}</p>
                </div>
              ))}
            </div>
            <p className="text-xs text-muted-foreground mt-4">
              Click any type or use the Upload Vital button to submit your medical records
            </p>
          </div>
        </div>
      </main>

      {/* Upload Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-8 max-w-sm w-full shadow-xl">
            <h3 className="text-2xl font-bold text-foreground mb-6">
              Upload Vital / Scan
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Type
                </label>
                <select
                  value={uploadType}
                  onChange={(e) => setUploadType(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-lg border border-input bg-white text-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition"
                >
                  <option value="">Select type...</option>
                  <option value="BP">Blood Pressure</option>
                  <option value="Sugar">Blood Sugar</option>
                  <option value="Weight">Weight</option>
                  <option value="CT Scan">CT Scan</option>
                  <option value="X-Ray">X-Ray</option>
                  <option value="Blood Report">Blood Report</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Value
                </label>
                <input
                  type="text"
                  value={newVitalValue}
                  onChange={(e) => setNewVitalValue(e.target.value)}
                  placeholder="Enter value"
                  className="w-full px-4 py-2.5 rounded-lg border border-input bg-white text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Unit
                </label>
                <input
                  type="text"
                  value={newVitalUnit}
                  onChange={(e) => setNewVitalUnit(e.target.value)}
                  placeholder="e.g., mmHg, mg/dL, lbs"
                  className="w-full px-4 py-2.5 rounded-lg border border-input bg-white text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  onClick={() => {
                    setShowUploadModal(false);
                    setNewVitalValue("");
                    setNewVitalUnit("");
                    setUploadType("");
                  }}
                  className="flex-1 px-4 py-2.5 rounded-lg border border-border text-foreground hover:bg-secondary-50 font-medium transition"
                >
                  Cancel
                </button>
                <button
                  onClick={handleUploadVital}
                  className="flex-1 px-4 py-2.5 rounded-lg bg-primary hover:bg-primary-300 text-primary-foreground font-medium transition-colors"
                >
                  Upload
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
