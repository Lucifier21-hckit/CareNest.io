import { useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { ArrowLeft, Plus, Edit2, Activity } from "lucide-react";

interface Prescription {
  id: string;
  date: string;
  medication: string[];
  notes: string;
}

interface Vital {
  date: string;
  bp: string;
  sugar: number;
  heartRate: number;
  weight: number;
}

const MOCK_PATIENTS: Record<string, any> = {
  "1": {
    id: "1",
    name: "John Doe",
    patientId: "PID-001",
    photo: "JD",
    age: 45,
    height: "5'10\"",
    weight: 180,
    disease: "Type 2 Diabetes",
    chronicConditions: ["Hypertension", "Hyperlipidemia"],
  },
  "2": {
    id: "2",
    name: "Sarah Johnson",
    patientId: "PID-002",
    photo: "SJ",
    age: 32,
    height: "5'6\"",
    weight: 140,
    disease: "Asthma",
    chronicConditions: ["Allergic Rhinitis"],
  },
  "3": {
    id: "3",
    name: "Michael Chen",
    patientId: "PID-003",
    photo: "MC",
    age: 58,
    height: "5'9\"",
    weight: 195,
    disease: "COPD",
    chronicConditions: ["Former Smoker", "Emphysema"],
  },
};

const MOCK_VITALS: Vital[] = [
  { date: "2024-01-15", bp: "130/85", sugar: 145, heartRate: 72, weight: 180 },
  { date: "2024-01-08", bp: "128/82", sugar: 138, heartRate: 70, weight: 178 },
  { date: "2024-01-01", bp: "132/88", sugar: 152, heartRate: 75, weight: 181 },
];

const MOCK_PRESCRIPTIONS: Prescription[] = [
  {
    id: "1",
    date: "2024-01-15",
    medication: ["Metformin 500mg (2x daily)", "Lisinopril 10mg (1x daily)"],
    notes: "Continue for 30 days. Follow up with lab work.",
  },
  {
    id: "2",
    date: "2024-01-01",
    medication: ["Atorvastatin 20mg (1x daily)", "Aspirin 81mg (1x daily)"],
    notes: "Maintain current dosage.",
  },
];

export default function PatientDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const patient = MOCK_PATIENTS[id || "1"] || MOCK_PATIENTS["1"];
  const [vitals] = useState<Vital[]>(MOCK_VITALS);
  const [prescriptions, setPrescriptions] = useState<Prescription[]>(
    MOCK_PRESCRIPTIONS
  );
  const [showPrescriptionModal, setShowPrescriptionModal] = useState(false);
  const [showVitalsHistory, setShowVitalsHistory] = useState(false);
  const [newPrescription, setNewPrescription] = useState({
    medication: "",
    notes: "",
  });

  const handleAddPrescription = () => {
    if (newPrescription.medication.trim()) {
      const prescription: Prescription = {
        id: String(prescriptions.length + 1),
        date: new Date().toISOString().split("T")[0],
        medication: newPrescription.medication
          .split("\n")
          .filter((m) => m.trim()),
        notes: newPrescription.notes,
      };
      setPrescriptions([prescription, ...prescriptions]);
      setNewPrescription({ medication: "", notes: "" });
      setShowPrescriptionModal(false);
    }
  };

  const latestVital = vitals[0];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-white border-b border-border sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 md:px-8 py-4">
          <button
            onClick={() => navigate("/doctor/dashboard")}
            className="flex items-center gap-2 text-primary hover:text-primary-300 font-medium transition"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Patients
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 md:px-8 py-12">
        {/* Patient Profile Section */}
        <div className="bg-white rounded-2xl p-8 mb-8 border border-border shadow-sm">
          <div className="flex flex-col md:flex-row gap-8 items-start md:items-center">
            <div className="w-32 h-32 rounded-full bg-gradient-to-br from-primary-100 to-primary-200 flex items-center justify-center flex-shrink-0">
              <span className="text-4xl font-bold text-primary">
                {patient.photo}
              </span>
            </div>

            <div className="flex-1">
              <h1 className="text-3xl font-bold text-foreground mb-2">
                {patient.name}
              </h1>
              <div className="space-y-1 text-sm text-muted-foreground mb-4">
                <p className="font-mono">ID: {patient.patientId}</p>
                <p>Age: {patient.age} years old</p>
                <p>Height: {patient.height} | Weight: {patient.weight} lbs</p>
              </div>

              <div className="mb-4">
                <p className="text-sm font-semibold text-foreground mb-2">
                  Primary Condition
                </p>
                <p className="text-lg text-primary font-semibold">
                  {patient.disease}
                </p>
              </div>

              <div>
                <p className="text-sm font-semibold text-foreground mb-2">
                  Chronic Conditions
                </p>
                <div className="flex flex-wrap gap-2">
                  {patient.chronicConditions.map((condition: string) => (
                    <span
                      key={condition}
                      className="px-3 py-1 bg-accent-50 text-accent-600 text-xs font-medium rounded-full border border-accent"
                    >
                      {condition}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Current Vitals Snapshot */}
        <div className="bg-white rounded-2xl p-8 mb-8 border border-border shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-foreground">Current Vitals</h2>
            <button
              onClick={() => setShowVitalsHistory(!showVitalsHistory)}
              className="flex items-center gap-2 px-4 py-2 text-primary hover:bg-primary-50 rounded-lg transition font-medium text-sm"
            >
              <Activity className="w-4 h-4" />
              View History
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            {/* BP Card */}
            <div className="bg-gradient-to-br from-primary-50 to-primary-100 rounded-xl p-4 border border-primary-200">
              <p className="text-xs font-medium text-primary-600 uppercase tracking-wider">
                Blood Pressure
              </p>
              <p className="text-2xl font-bold text-primary mt-2">
                {latestVital.bp}
              </p>
              <p className="text-xs text-primary-600 mt-1">mmHg</p>
            </div>

            {/* Sugar Card */}
            <div className="bg-gradient-to-br from-secondary-50 to-secondary-100 rounded-xl p-4 border border-secondary">
              <p className="text-xs font-medium text-secondary-700 uppercase tracking-wider">
                Blood Sugar
              </p>
              <p className="text-2xl font-bold text-secondary-700 mt-2">
                {latestVital.sugar}
              </p>
              <p className="text-xs text-secondary-700 mt-1">mg/dL</p>
            </div>

            {/* Heart Rate Card */}
            <div className="bg-gradient-to-br from-accent-50 to-accent-100 rounded-xl p-4 border border-accent">
              <p className="text-xs font-medium text-accent-600 uppercase tracking-wider">
                Heart Rate
              </p>
              <p className="text-2xl font-bold text-accent-600 mt-2">
                {latestVital.heartRate}
              </p>
              <p className="text-xs text-accent-600 mt-1">BPM</p>
            </div>

            {/* Weight Card */}
            <div className="bg-gradient-to-br from-success-50 to-green-100 rounded-xl p-4 border border-success">
              <p className="text-xs font-medium text-success-700 uppercase tracking-wider">
                Weight
              </p>
              <p className="text-2xl font-bold text-success-700 mt-2">
                {latestVital.weight}
              </p>
              <p className="text-xs text-success-700 mt-1">lbs</p>
            </div>
          </div>

          <p className="text-xs text-muted-foreground">
            Last recorded: {latestVital.date}
          </p>
        </div>

        {/* Vitals History */}
        {showVitalsHistory && (
          <div className="bg-white rounded-2xl p-8 mb-8 border border-border shadow-sm">
            <h3 className="text-xl font-bold text-foreground mb-6">
              Vitals History
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left px-4 py-3 font-semibold text-foreground">
                      Date
                    </th>
                    <th className="text-left px-4 py-3 font-semibold text-foreground">
                      BP
                    </th>
                    <th className="text-left px-4 py-3 font-semibold text-foreground">
                      Sugar
                    </th>
                    <th className="text-left px-4 py-3 font-semibold text-foreground">
                      HR
                    </th>
                    <th className="text-left px-4 py-3 font-semibold text-foreground">
                      Weight
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {vitals.map((vital) => (
                    <tr key={vital.date} className="border-b border-border hover:bg-secondary-50 transition">
                      <td className="px-4 py-3 text-muted-foreground">
                        {vital.date}
                      </td>
                      <td className="px-4 py-3 font-medium text-foreground">
                        {vital.bp}
                      </td>
                      <td className="px-4 py-3 font-medium text-foreground">
                        {vital.sugar} mg/dL
                      </td>
                      <td className="px-4 py-3 font-medium text-foreground">
                        {vital.heartRate} BPM
                      </td>
                      <td className="px-4 py-3 font-medium text-foreground">
                        {vital.weight} lbs
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Prescription Section */}
        <div className="bg-white rounded-2xl p-8 border border-border shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-foreground">Prescriptions</h2>
            <div className="flex gap-3">
              <button
                onClick={() => setShowPrescriptionModal(true)}
                className="flex items-center gap-2 px-4 py-2 bg-primary hover:bg-primary-300 text-primary-foreground font-medium rounded-lg transition-colors text-sm"
              >
                <Plus className="w-4 h-4" />
                Add Prescription
              </button>
            </div>
          </div>

          <div className="space-y-4">
            {prescriptions.map((prescription) => (
              <div
                key={prescription.id}
                className="border border-border rounded-xl p-6 hover:border-primary-300 transition"
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <p className="text-sm text-muted-foreground">
                      Prescribed on {prescription.date}
                    </p>
                    <h3 className="text-lg font-semibold text-foreground mt-1">
                      Prescription #{prescription.id}
                    </h3>
                  </div>
                  <button className="p-2 hover:bg-secondary-50 rounded-lg transition">
                    <Edit2 className="w-4 h-4 text-muted-foreground" />
                  </button>
                </div>

                <div className="mb-4">
                  <p className="text-sm font-medium text-foreground mb-2">
                    Medications
                  </p>
                  <ul className="space-y-1">
                    {prescription.medication.map((med, idx) => (
                      <li
                        key={idx}
                        className="text-sm text-foreground flex items-start gap-2"
                      >
                        <span className="text-primary mt-1">•</span>
                        {med}
                      </li>
                    ))}
                  </ul>
                </div>

                {prescription.notes && (
                  <div className="bg-secondary-50 rounded-lg p-3">
                    <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                      Notes
                    </p>
                    <p className="text-sm text-foreground mt-1">
                      {prescription.notes}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Add Prescription Modal */}
      {showPrescriptionModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-8 max-w-lg w-full shadow-xl">
            <h3 className="text-2xl font-bold text-foreground mb-6">
              Add New Prescription
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Medications (one per line)
                </label>
                <textarea
                  value={newPrescription.medication}
                  onChange={(e) =>
                    setNewPrescription({
                      ...newPrescription,
                      medication: e.target.value,
                    })
                  }
                  placeholder="Metformin 500mg (2x daily)&#10;Lisinopril 10mg (1x daily)"
                  className="w-full px-4 py-2.5 rounded-lg border border-input bg-white text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition"
                  rows={4}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Notes
                </label>
                <textarea
                  value={newPrescription.notes}
                  onChange={(e) =>
                    setNewPrescription({
                      ...newPrescription,
                      notes: e.target.value,
                    })
                  }
                  placeholder="Any notes or instructions"
                  className="w-full px-4 py-2.5 rounded-lg border border-input bg-white text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition"
                  rows={3}
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  onClick={() => {
                    setShowPrescriptionModal(false);
                    setNewPrescription({ medication: "", notes: "" });
                  }}
                  className="flex-1 px-4 py-2.5 rounded-lg border border-border text-foreground hover:bg-secondary-50 font-medium transition"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddPrescription}
                  className="flex-1 px-4 py-2.5 rounded-lg bg-primary hover:bg-primary-300 text-primary-foreground font-medium transition-colors"
                >
                  Add Prescription
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
