import { Link } from "react-router-dom";
import { Heart, Users } from "lucide-react";

export default function Login() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-primary-50 to-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Heart className="w-8 h-8 text-primary fill-primary" />
            <h1 className="text-3xl font-bold text-foreground">CareNest</h1>
          </div>
          <p className="text-muted-foreground text-lg">
            Healthcare Management Platform
          </p>
        </div>

        {/* Role Selection */}
        <div className="space-y-6">
          <h2 className="text-center text-xl font-semibold text-foreground mb-8">
            Who are you?
          </h2>

          {/* Doctor Card */}
          <Link to="/doctor/signup">
            <div className="group relative bg-white rounded-2xl p-8 shadow-sm hover:shadow-lg transition-all duration-300 border border-border cursor-pointer hover:border-primary-300">
              <div className="text-center">
                <div className="flex justify-center mb-4">
                  <div className="w-16 h-16 rounded-full bg-primary-100 flex items-center justify-center group-hover:bg-primary-200 transition-colors">
                    <svg
                      className="w-8 h-8 text-primary"
                      fill="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z" />
                    </svg>
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-2">Doctor</h3>
                <p className="text-muted-foreground">
                  Manage patients and prescriptions
                </p>
              </div>
            </div>
          </Link>

          {/* Patient Card */}
          <Link to="/patient/login">
            <div className="group relative bg-white rounded-2xl p-8 shadow-sm hover:shadow-lg transition-all duration-300 border border-border cursor-pointer hover:border-secondary">
              <div className="text-center">
                <div className="flex justify-center mb-4">
                  <div className="w-16 h-16 rounded-full bg-secondary-50 flex items-center justify-center group-hover:bg-secondary-100 transition-colors">
                    <Users className="w-8 h-8 text-secondary-600" />
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-2">
                  Patient / Guardian
                </h3>
                <p className="text-muted-foreground">
                  View health records and medications
                </p>
              </div>
            </div>
          </Link>
        </div>

        {/* Footer */}
        <p className="text-center text-sm text-muted-foreground mt-12">
          Professional healthcare management at your fingertips
        </p>
      </div>
    </div>
  );
}
