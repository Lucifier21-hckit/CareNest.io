import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Plus, LogOut } from "lucide-react";

interface Patient {
  id: string;
  name: string;
  patientId: string;
  photo?: string;
}

const MOCK_PATIENTS: Patient[] = [
  {
    id: "1",
    name: "John Doe",
    patientId: "PID-001",
    photo: "JD",
  },
  {
    id: "2",
    name: "Sarah Johnson",
    patientId: "PID-002",
    photo: "SJ",
  },
  {
    id: "3",
    name: "Michael Chen",
    patientId: "PID-003",
    photo: "MC",
  },
  {
    id: "4",
    name: "Emma Wilson",
    patientId: "PID-004",
    photo: "EW",
  },
  {
    id: "5",
    name: "David Brown",
    patientId: "PID-005",
    photo: "DB",
  },
];

export default function DoctorDashboard() {
  const [doctor, setDoctor] = useState<any>(null);
  const [patients, setPatients] = useState<Patient[]>(MOCK_PATIENTS);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newPatientName, setNewPatientName] = useState("");

  useEffect(() => {
    // Load doctor from localStorage
    const doctorData = localStorage.getItem("doctor");
    if (doctorData) {
      setDoctor(JSON.parse(doctorData));
    }
  }, []);

  const handleAddPatient = () => {
    if (newPatientName.trim()) {
      const initials = newPatientName
        .split(" ")
        .map((n) => n[0])
        .join("");
      const newPatient: Patient = {
        id: String(patients.length + 1),
        name: newPatientName,
        patientId: `PID-${String(patients.length + 1).padStart(3, "0")}`,
        photo: initials,
      };
      setPatients([...patients, newPatient]);
      setNewPatientName("");
      setShowAddModal(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("doctor");
    window.location.href = "/login";
  };

  if (!doctor) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-foreground mb-4">Loading...</p>
          <Link
            to="/login"
            className="text-primary hover:text-primary-300 font-medium"
          >
            Back to Login
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-white border-b border-border sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 md:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-primary-100 flex items-center justify-center">
                <span className="text-lg font-bold text-primary">
                  {doctor.fullName
                    .split(" ")
                    .map((n: string) => n[0])
                    .join("")}
                </span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">
                  {doctor.fullName}
                </h1>
                <p className="text-sm text-muted-foreground font-mono">
                  {doctor.doctorId}
                </p>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-4 py-2 text-foreground hover:bg-secondary-50 rounded-lg transition"
            >
              <LogOut className="w-4 h-4" />
              <span className="text-sm font-medium">Logout</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 md:px-8 py-12">
        {/* Patient Overview Section */}
        <div className="mb-12">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold text-foreground">My Patients</h2>
              <p className="text-muted-foreground mt-1">
                {patients.length} patient{patients.length !== 1 ? "s" : ""} in your care
              </p>
            </div>
            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-2 px-6 py-3 bg-primary hover:bg-primary-300 text-primary-foreground font-semibold rounded-lg transition-colors shadow-sm hover:shadow-md"
            >
              <Plus className="w-5 h-5" />
              Add Patient
            </button>
          </div>

          {/* Patient Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
            {patients.map((patient) => (
              <Link key={patient.id} to={`/doctor/patient/${patient.id}`}>
                <div className="group bg-white rounded-2xl p-6 shadow-sm hover:shadow-lg border border-border transition-all duration-300 hover:border-primary-300 cursor-pointer text-center">
                  {/* Patient Photo Circle */}
                  <div className="flex justify-center mb-4">
                    <div className="w-14 h-14 rounded-full bg-gradient-to-br from-primary-100 to-primary-200 flex items-center justify-center group-hover:shadow-md transition-shadow">
                      <span className="text-lg font-bold text-primary">
                        {patient.photo}
                      </span>
                    </div>
                  </div>

                  {/* Patient Info */}
                  <h3 className="font-semibold text-foreground group-hover:text-primary transition">
                    {patient.name}
                  </h3>
                  <p className="text-xs text-muted-foreground mt-1 font-mono">
                    {patient.patientId}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </main>

      {/* Add Patient Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-8 max-w-sm w-full shadow-xl">
            <h3 className="text-2xl font-bold text-foreground mb-6">
              Add New Patient
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Patient Name
                </label>
                <input
                  type="text"
                  value={newPatientName}
                  onChange={(e) => setNewPatientName(e.target.value)}
                  placeholder="Enter patient name"
                  className="w-full px-4 py-2.5 rounded-lg border border-input bg-white text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition"
                  onKeyPress={(e) => {
                    if (e.key === "Enter") {
                      handleAddPatient();
                    }
                  }}
                  autoFocus
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  onClick={() => {
                    setShowAddModal(false);
                    setNewPatientName("");
                  }}
                  className="flex-1 px-4 py-2.5 rounded-lg border border-border text-foreground hover:bg-secondary-50 font-medium transition"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddPatient}
                  className="flex-1 px-4 py-2.5 rounded-lg bg-primary hover:bg-primary-300 text-primary-foreground font-medium transition-colors"
                >
                  Add Patient
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
